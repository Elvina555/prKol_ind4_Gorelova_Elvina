﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Myzkatalog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Hashtable Hash = new Hashtable();
        

        private void button1_Click(object sender, EventArgs e)
        {
            string nomer = Convert.ToString(numericUpDown1.Value);
            string isp = textBox1.Text;
            string nasv = textBox2.Text;
            Disk d = new Disk();
            d.Nomer = nomer;
            d.Isp = isp;
            d.Nazv = nasv;
           if(Hash.Contains(nomer))
            {
                MessageBox.Show("Такой номер диска уже существует");
            }
            else
            {
                if(Hash!=null)
                {
                    Hash.Add(d.Nomer, d);
                }
            }
            if (Hash.Contains(nasv))
            {
                MessageBox.Show("Название такой песни уже существует");
            }
            else
            {
                if (Hash != null)
                {
                    Hash.Add(d.Nazv, d);
                }
            }
            if (nomer !="" && isp != "" && nasv != "")
            {
                dataGridView1.Rows.Add(nomer, isp, nasv);
            }
            else
                MessageBox.Show("Заполните поле");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("каталог", "номер диска");
            dataGridView1.Columns.Add("каталог", "исполнитель");
            dataGridView1.Columns.Add("каталог", "название песни");
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox3.Text=="")
            {
                MessageBox.Show("Введите данные корректно");
            }
            else
            {
                string st = textBox3.Text;
                for(int i=0;i<dataGridView1.RowCount;i++)
                {
                    dataGridView1.Rows[i].Selected = false;
                    for(int j=0;j<dataGridView1.ColumnCount;j++)
                    {
                        if(dataGridView1.Rows[i].Cells[j].Value!=null)
                        {
                            if(dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(st))
                            {
                                dataGridView1.Rows[i].Selected = true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
              int ydalen = dataGridView1.SelectedCells[0].RowIndex;
              Hash.Remove(dataGridView1.SelectedRows);
              dataGridView1.Rows.RemoveAt(ydalen);
            
        }
    }
}
