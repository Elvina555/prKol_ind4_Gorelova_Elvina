﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myzkatalog
{
    class Disk
    {
        private string nomer;
        private string isp;
        private string nazv;
        public string Nomer
        {
            get { return nomer; }
            set { nomer = value; }
        }
        public string Isp
        {
            get { return isp; }
            set { isp = value; }
        }
        public string Nazv
        {
            get { return nazv; }
            set { nazv = value; }
        }
    }
}
